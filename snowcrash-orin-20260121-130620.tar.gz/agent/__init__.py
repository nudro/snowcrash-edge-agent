"""Agentic LLM with MCP tools integration."""

