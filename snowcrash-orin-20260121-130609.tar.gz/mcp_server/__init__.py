"""MCP Server for Snowcrash - Agentic SLM with local tools."""

