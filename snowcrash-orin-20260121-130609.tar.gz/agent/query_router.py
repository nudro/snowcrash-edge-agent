"""
Query Understanding Router - Routes queries to appropriate tools using LLM reasoning.

Uses prompt templates to understand semantic relationships and select the right tool.
"""
import asyncio
from typing import Dict, Any, Optional
from agent.prompt_templates import (
    QUERY_ROUTER_TEMPLATE,
    OBJECT_DETECTION_TEMPLATE,
    COLOR_DETECTION_TEMPLATE,
    DISTANCE_SPATIAL_TEMPLATE,
    TRACKING_TEMPLATE,
    RESPONSE_FORMATTING_TEMPLATE,
    parse_router_response,
    parse_detection_response,
    parse_color_response,
    parse_distance_response,
    parse_tracking_response
)


class QueryUnderstandingRouter:
    """
    Routes user queries to appropriate tools using LLM-based semantic understanding.
    
    Handles:
    - Object part mapping (sweater → person)
    - Spatial relationships (wrt, relative to)
    - Distance comparisons
    - Environment inference
    """
    
    def __init__(self, llm, verbose: bool = False):
        """
        Initialize query router.
        
        Args:
            llm: LLM instance (DockerLLMAdapter or LlamaCpp)
            verbose: Print debug messages
        """
        self.llm = llm
        self.verbose = verbose
    
    async def understand_query(self, query: str) -> Dict[str, Any]:
        """
        Understand user query and determine tool/parameters.
        
        Args:
            query: User query string
            
        Returns:
            Dict with tool, object_class, query_type, parameters, etc.
        """
        if self.verbose:
            print(f"[QueryRouter] Understanding query: {query}")
        
        # Format router prompt
        router_prompt = QUERY_ROUTER_TEMPLATE.format_messages(query=query)
        
        # Extract system and user messages
        system_msg = None
        user_msg = None
        for msg in router_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        # Call LLM with system prompt
        try:
            if hasattr(self.llm, '_acall'):
                # DockerLLMAdapter or async LLM
                response = await self.llm._acall(
                    user_msg,
                    system_prompt=system_msg
                )
            else:
                # Sync LLM (LlamaCpp)
                response = await asyncio.to_thread(
                    self.llm.invoke,
                    router_prompt
                )
                if isinstance(response, str):
                    pass  # Already a string
                else:
                    response = response.content if hasattr(response, 'content') else str(response)
            
            # Parse response
            parsed = parse_router_response(response)
            
            if self.verbose:
                print(f"[QueryRouter] Parsed: {parsed}")
            
            return parsed
            
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Error: {e}")
            # Fallback to default
            return {
                "tool": None,
                "object_class": None,
                "secondary_object_class": None,
                "query_type": "unknown",
                "reasoning": f"Error: {str(e)}",
                "parameters": {}
            }
    
    async def understand_detection_query(self, query: str) -> Dict[str, Any]:
        """Understand object detection query with semantic mapping."""
        detection_prompt = OBJECT_DETECTION_TEMPLATE.format_messages(query=query)
        
        system_msg = None
        user_msg = None
        for msg in detection_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        try:
            if hasattr(self.llm, '_acall'):
                response = await self.llm._acall(user_msg, system_prompt=system_msg)
            else:
                response = await asyncio.to_thread(self.llm.invoke, detection_prompt)
                if not isinstance(response, str):
                    response = response.content if hasattr(response, 'content') else str(response)
            
            return parse_detection_response(response)
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Detection query error: {e}")
            return {"object_class": None, "is_count_query": False, "is_environment_query": False}
    
    async def understand_color_query(self, query: str) -> Dict[str, Any]:
        """Understand color detection query with object part mapping."""
        color_prompt = COLOR_DETECTION_TEMPLATE.format_messages(query=query)
        
        system_msg = None
        user_msg = None
        for msg in color_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        try:
            if hasattr(self.llm, '_acall'):
                response = await self.llm._acall(user_msg, system_prompt=system_msg)
            else:
                response = await asyncio.to_thread(self.llm.invoke, color_prompt)
                if not isinstance(response, str):
                    response = response.content if hasattr(response, 'content') else str(response)
            
            return parse_color_response(response)
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Color query error: {e}")
            return {"object_class": None, "region_type": "whole", "specific_part": None}
    
    async def understand_distance_query(self, query: str) -> Dict[str, Any]:
        """Understand distance/spatial query."""
        distance_prompt = DISTANCE_SPATIAL_TEMPLATE.format_messages(query=query)
        
        system_msg = None
        user_msg = None
        for msg in distance_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        try:
            if hasattr(self.llm, '_acall'):
                response = await self.llm._acall(user_msg, system_prompt=system_msg)
            else:
                response = await asyncio.to_thread(self.llm.invoke, distance_prompt)
                if not isinstance(response, str):
                    response = response.content if hasattr(response, 'content') else str(response)
            
            return parse_distance_response(response)
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Distance query error: {e}")
            return {"primary_object": None, "reference_object": None, "query_type": "distance"}
    
    async def understand_tracking_query(self, query: str) -> Dict[str, Any]:
        """Understand tracking query."""
        tracking_prompt = TRACKING_TEMPLATE.format_messages(query=query)
        
        system_msg = None
        user_msg = None
        for msg in tracking_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        try:
            if hasattr(self.llm, '_acall'):
                response = await self.llm._acall(user_msg, system_prompt=system_msg)
            else:
                response = await asyncio.to_thread(self.llm.invoke, tracking_prompt)
                if not isinstance(response, str):
                    response = response.content if hasattr(response, 'content') else str(response)
            
            return parse_tracking_response(response)
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Tracking query error: {e}")
            return {"object_class": None, "track_id": None, "query_type": "tracking"}
    
    async def format_response(self, user_query: str, tool_results: str) -> str:
        """Format tool results into natural language response."""
        format_prompt = RESPONSE_FORMATTING_TEMPLATE.format_messages(
            user_query=user_query,
            tool_results=tool_results
        )
        
        system_msg = None
        user_msg = None
        for msg in format_prompt:
            if msg.type == "system":
                system_msg = msg.content
            elif msg.type == "human":
                user_msg = msg.content
        
        try:
            if hasattr(self.llm, '_acall'):
                response = await self.llm._acall(user_msg, system_prompt=system_msg)
            else:
                response = await asyncio.to_thread(self.llm.invoke, format_prompt)
                if not isinstance(response, str):
                    response = response.content if hasattr(response, 'content') else str(response)
            
            return response.strip()
        except Exception as e:
            if self.verbose:
                print(f"[QueryRouter] Format response error: {e}")
            # Fallback to raw tool results
            return tool_results

