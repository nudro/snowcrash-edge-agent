"""
Prompt Templates for Semantic Query Understanding.

Provides 6 specialized prompt templates for different query types:
1. Query Understanding Router (master template)
2. Object Detection Template
3. Color Detection Template
4. Distance & Spatial Template
5. Tracking Template
6. Response Formatting Template
"""
import json
from typing import Dict, Any, Optional, List
from langchain_core.prompts import ChatPromptTemplate


# ============================================================================
# Template 1: Query Understanding Router (Master Template)
# ============================================================================

QUERY_ROUTER_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a query understanding system for a computer vision agent.

Your job is to analyze user queries and determine:
1. Which tool to use
2. What object class(es) to detect
3. Any semantic mappings needed (e.g., "sweater" → "person")
4. Query parameters (distance comparison, spatial relationships, etc.)

IMPORTANT: Only route to vision tools if the query is about:
- Detecting objects in images/video
- Tracking objects
- Colors of objects
- Distances to objects
- Statistics about detections
- Viewing video/GUI
- Environment inference based on objects

DO NOT route to vision tools for:
- General knowledge questions (e.g., "how to bake a cake")
- Questions not requiring visual analysis
- Non-vision queries

Available tools:
- yolo_object_detection: Detect objects in images/video
- get_detection_statistics: Get aggregated statistics
- estimate_object_distances: Estimate distance to objects
- track_objects: Track objects with persistent IDs
- color_detection: Detect colors of objects (built-in)
- gui_viewer: Open visual interface

Semantic understanding:
- Clothing items (sweater, shirt, jacket, pants, dress) → belong to "person" objects
- Body parts (face, hand, foot, head) → belong to "person" objects
- "wrt" or "with respect to" → spatial relationship query
- "which X is closer" → distance comparison query
- Multiple objects together → may indicate environment type (street, park, restaurant)
- Synonyms: vehicle→car, auto→car, bike→bicycle, motorbike→motorcycle

Respond ONLY with valid JSON in this exact format:
{{
  "tool": "tool_name" or null (null if not a vision query),
  "object_class": "person" or null,
  "secondary_object_class": "dog" or null (for spatial queries),
  "query_type": "detection|color|distance|distance_comparison|spatial|tracking|movement|speed|duration|statistics|position|track_data|gui|followup|general",
  "reasoning": "brief explanation",
  "parameters": {{
    "is_spatial": true/false,
    "is_comparison": true/false,
    "needs_track_id": true/false,
    "track_id": null or number
  }}
}}"""),
    ("human", "User query: {query}")
])


# ============================================================================
# Template 2: Object Detection Template
# ============================================================================

OBJECT_DETECTION_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are an object detection query understanding system.

You understand semantic relationships:
- Object parts: "sweater", "shirt", "jacket" → detect "person" objects
- Synonyms: "vehicle" → "car", "auto" → "car", "bike" → "bicycle"
- Plural forms: "cars" → "car", "people" → "person"
- Environment inference: multiple objects → environment type
  - cars + traffic lights → street
  - benches + trees + dogs → park
  - chairs + tables + people → restaurant

Given a detection query, extract:
1. Primary object class to detect
2. Whether this is a counting query ("how many")
3. Whether this is an environment inference query ("what is the environment")

Respond with JSON:
{{
  "object_class": "person" or null (null = detect all),
  "is_count_query": true/false,
  "is_environment_query": true/false,
  "semantic_mapping": "sweater → person" or null
}}"""),
    ("human", "Detection query: {query}")
])


# ============================================================================
# Template 3: Color Detection Template
# ============================================================================

COLOR_DETECTION_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a color detection query understanding system.

You understand that color queries often refer to:
- Clothing items: "sweater", "shirt", "jacket", "pants", "dress" → detect "person" and analyze clothing region
- Body parts: "face", "hand" → detect "person" and analyze specific region
- Object parts: "car door", "wheel" → detect parent object ("car") and analyze specific region

Color detection works on detected objects, so you need to:
1. Map the query to the parent object class
2. Identify if a specific region is requested (clothing vs whole object)

Respond with JSON:
{{
  "object_class": "person" or "car" etc. (parent object),
  "region_type": "clothing|body_part|whole|specific_part",
  "specific_part": "sweater" or null,
  "semantic_mapping": "sweater → person (clothing region)"
}}"""),
    ("human", "Color query: {query}")
])


# ============================================================================
# Template 4: Distance & Spatial Template
# ============================================================================

DISTANCE_SPATIAL_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a distance and spatial relationship query understanding system.

You understand:
- "wrt" or "with respect to" = spatial relationship query
- "relative to" = spatial relationship query
- "which X is closer" = distance comparison query
- "how far is X from Y" = spatial distance query

For spatial queries, you need:
1. Primary object (e.g., "person")
2. Reference object (e.g., "dog")
3. Relationship type: "distance|position|direction"

Respond with JSON:
{{
  "primary_object": "person",
  "reference_object": "dog" or null,
  "query_type": "distance|distance_comparison|spatial_relationship",
  "relationship_type": "wrt|relative_to|distance_from|closer|farther" or null,
  "is_comparison": true/false
}}"""),
    ("human", "Distance/spatial query: {query}")
])


# ============================================================================
# Template 5: Tracking Template
# ============================================================================

TRACKING_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a tracking query understanding system.

You understand tracking-related queries:
- "track objects" → start tracking
- "how fast is X" → speed query
- "are objects moving" → movement query
- "how long has X been in frame" → duration query
- "data for track ID 5" → track data query

Extract:
1. Object class (if specified)
2. Track ID (if specified, e.g., "ID:5", "track 3")
3. Query type: tracking|speed|movement|duration|track_data

Respond with JSON:
{{
  "object_class": "person" or null,
  "track_id": 5 or null,
  "query_type": "tracking|speed|movement|duration|track_data",
  "needs_duration": true/false
}}"""),
    ("human", "Tracking query: {query}")
])


# ============================================================================
# Template 6: Response Formatting Template
# ============================================================================

RESPONSE_FORMATTING_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a tactical AI assistant operating in a real-time surveillance environment.

Communication Protocol:
- Respond in brief, direct operational style
- Use tactical terminology (target, status, confirm, negative, intel, situational awareness)
- Keep ALL responses under 45 words - be concise
- No explanations unless mission-critical
- Format: [Status] [Essential info] [Action/Result]
- Use military time references and operational brevity

When formatting tool results:
- Be specific: "Person (ID:3): red sweater, 5.2m away"
- For comparisons: "Closest: car at 3.1m. Farthest: truck at 12.5m"
- For spatial: "Person 2.3m northeast of dog"
- For color: "Person: red sweater (RGB: 255,0,0)"
- For movement: "Moving: car (ID:1) 15.3 px/s, person (ID:2) 2.1 px/s"

Respond operationally:"""),
    ("human", """User asked: {user_query}

Tool results: {tool_results}

Format a concise operational response:""")
])


# ============================================================================
# Helper Functions
# ============================================================================

def parse_router_response(response: str) -> Dict[str, Any]:
    """Parse JSON response from query router."""
    try:
        # Try to extract JSON from response
        response = response.strip()
        
        # If response is wrapped in markdown code blocks, extract JSON
        if "```json" in response:
            start = response.find("```json") + 7
            end = response.find("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            response = response[start:end].strip()
        
        return json.loads(response)
    except json.JSONDecodeError as e:
        # Fallback: return default structure
        return {
            "tool": None,
            "object_class": None,
            "secondary_object_class": None,
            "query_type": "unknown",
            "reasoning": f"Failed to parse: {str(e)}",
            "parameters": {}
        }


def parse_detection_response(response: str) -> Dict[str, Any]:
    """Parse JSON response from object detection template."""
    try:
        response = response.strip()
        if "```json" in response:
            start = response.find("```json") + 7
            end = response.find("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            response = response[start:end].strip()
        
        return json.loads(response)
    except json.JSONDecodeError:
        return {
            "object_class": None,
            "is_count_query": False,
            "is_environment_query": False,
            "semantic_mapping": None
        }


def parse_color_response(response: str) -> Dict[str, Any]:
    """Parse JSON response from color detection template."""
    try:
        response = response.strip()
        if "```json" in response:
            start = response.find("```json") + 7
            end = response.find("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            response = response[start:end].strip()
        
        return json.loads(response)
    except json.JSONDecodeError:
        return {
            "object_class": None,
            "region_type": "whole",
            "specific_part": None,
            "semantic_mapping": None
        }


def parse_distance_response(response: str) -> Dict[str, Any]:
    """Parse JSON response from distance/spatial template."""
    try:
        response = response.strip()
        if "```json" in response:
            start = response.find("```json") + 7
            end = response.find("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            response = response[start:end].strip()
        
        return json.loads(response)
    except json.JSONDecodeError:
        return {
            "primary_object": None,
            "reference_object": None,
            "query_type": "distance",
            "relationship_type": None,
            "is_comparison": False
        }


def parse_tracking_response(response: str) -> Dict[str, Any]:
    """Parse JSON response from tracking template."""
    try:
        response = response.strip()
        if "```json" in response:
            start = response.find("```json") + 7
            end = response.find("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            response = response[start:end].strip()
        
        return json.loads(response)
    except json.JSONDecodeError:
        return {
            "object_class": None,
            "track_id": None,
            "query_type": "tracking",
            "needs_duration": False
        }

