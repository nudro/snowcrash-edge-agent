"""Tools for Snowcrash MCP Server."""

